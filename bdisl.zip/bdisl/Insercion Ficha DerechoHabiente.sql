------------------------INSERCIONES DE LA FICHA DEL DERECHO HABIENTE

--VINCULO FAMILIA
GO
INSERT INTO vinculofamiliares(id, codigo, descripcion, descripcionabreviado) VALUES
('ARCHICEN000000000001', '02', 'C�NYUGE', 'C�NYUGE'),
('ARCHICEN000000000002', '03', 'CONCUBINA(O)', 'CONCUBINA(O)'),
('ARCHICEN000000000003', '04', 'GESTANTE', 'GESTANTE'),
('ARCHICEN000000000004', '05', 'HIJO MENOR DE EDAD', 'HIJO MENOR DE EDAD'),
('ARCHICEN000000000005', '06', 'HIJO MAYOR DE EDAD INCAPACITADO PERMANENTE', 'HIJO MAYOR EDAD INCAP PERM');

--TIPO BAJA

--TIPO DE DOCUMENTO QUE ACREDITA LA PATERNIDAD
GO
INSERT INTO tipodocumentoacreditas(id, codigo, descripcion, descripcionabreviado, vinculofamiliar_id) VALUES
('ARCHICEN000000000001','01','Acta/Partida Matrimonio Civil', 'Acta/Partida Matrimonio Civil','ARCHICEN000000000001'),
('ARCHICEN000000000002','01','Acta/Partida Matrimonio Inscrito en Registro Consular Peruano', 'Acta/Partida Matrimonio Insc. Registro Consular Peruano','ARCHICEN000000000001'),
('ARCHICEN000000000003','01','Acta/Partida Matrimonio Realizado en el Exterior', 'Acta/Partida Matrimonio Realizado en el Exterior','ARCHICEN000000000001'),

('ARCHICEN000000000004','02','Escritura P�blica de Reconocimiento de la Uni�n de Hecho Ley N.� 29560', 'Escritura P�blica de Recon. Uni�n Hecho Ley 29560','ARCHICEN000000000002'),
('ARCHICEN000000000005','02','Resoluci�n Judicial de Reconocimiento de la Uni�n de Hecho', 'Res. Judicial de Reconocimiento Uni�n Hecho','ARCHICEN000000000002'),


('ARCHICEN000000000006','03','Escritura P�blica', 'Escritura P�blica','ARCHICEN000000000003'),
('ARCHICEN000000000007','03','Testamento', 'Testamento','ARCHICEN000000000003'),
('ARCHICEN000000000008','03','Sentencia de declaratoria de paternidad', 'Sentencia Declaratoria de Paternidad','ARCHICEN000000000003'),

('ARCHICEN000000000009','04','Acta Nac/Doc An�logo Sust Filiaci�n', 'Acta Nac/Doc An�logo Sust Filiaci�n','ARCHICEN000000000004'),

('ARCHICEN000000000010','05','Resoluci�n de Incapacidad', 'Resoluci�n de Incapacidad','ARCHICEN000000000005');



GO 
INSERT INTO tipobajas (id, codigo, descripcion, descripcionabreviado) VALUES
('ARCHICEN000000000001', '02',	'FALLECIMIENTO', 'FALLECIMIENTO'),
('ARCHICEN000000000002', '03',	'OTROS MOTIVOS NO PREVISTOS', 'OTROS MOTIVOS NO PREVISTOS'),
('ARCHICEN000000000003', '04',	'DIVORCIO O DISOLUCI�N DE V�NCULO MATRIMONIAL', 'DIVORCIO O DISOL. DE V�NC MATRIM.'),
('ARCHICEN000000000004', '05',	'FIN DE CONCUBINATO', 'FIN DE CONCUBINATO'),
('ARCHICEN000000000005', '06',	'FIN DE LA GESTACI�N', 'FIN DE LA GESTACI�N'),
('ARCHICEN000000000006', '07',	'HIJO ADQUIERE MAYOR�A DE EDAD', 'HIJO ADQUIERE MAYOR�A DE EDAD'),
('ARCHICEN000000000007', '08',	'ERROR EN EL REGISTRO', 'ERROR EN EL REGISTRO'),
('ARCHICEN000000000008', '09',	'DERECHOHABIENTE ADQUIERE CONDICI�N DE ASEGURADO REGULAR', 'DH ADQUIERE CONDIC DE ASEG REGULAR');