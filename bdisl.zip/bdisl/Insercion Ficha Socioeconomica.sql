------------------------INSERCIONES DE LA FICHA SOCIOECON�MICA

--TIPO VIVIENDA
GO
INSERT INTO tipoviviendas(id, descripcion) VALUES
('ARCHICEN000000000001','Propia'),
('ARCHICEN000000000002',  'Alquilada'),
('ARCHICEN000000000003', 'Departamento en Edificio '),
('ARCHICEN000000000004', 'Alojado en Casa de un Familia'),
('ARCHICEN000000000005', 'Cuarto'),
('ARCHICEN000000000006', 'Otros');

--PARTES DE LA CASA
GO
INSERT INTO casapartes(id, descripcion, activo) VALUES
('ARCHICEN000000000001','Sala',1), 
('ARCHICEN000000000002', 'Comedor',1),
('ARCHICEN000000000003','Habitaciones',1),
('ARCHICEN000000000004','Cocina',1),
('ARCHICEN000000000005','Servicios Higi�nicos',1);


--SERVICIOS DE LA CASA
GO
INSERT INTO servicios(id, descripcion, activo) VALUES
('ARCHICEN000000000001','Agua',1),
('ARCHICEN000000000002',  'Desag�e',1),
('ARCHICEN000000000003', 'Luz El�ctrica',1),
('ARCHICEN000000000004', 'Tel�fono',1),
('ARCHICEN000000000005', 'Internet',1),
('ARCHICEN000000000006', 'Cable',1);

--ENFERMEDADES 
GO
INSERT INTO enfermedades(id, descripcion, activo) VALUES
('ARCHICEN000000000001','Respiratorias',1), 
('ARCHICEN000000000002', 'Cardiovascular',1),
('ARCHICEN000000000003','Hipertensi�n',1),
('ARCHICEN000000000004','Diabetes',1),
('ARCHICEN000000000005','Migra�a',1),
('ARCHICEN000000000006','Otras',1);



--MATERIALES DE CONSTRUCCI�N
GO
INSERT INTO construccionmateriales(id, descripcion) VALUES
('ARCHICEN000000000001','Ladrillo'),
('ARCHICEN000000000002',  'Adobe'),
('ARCHICEN000000000003', 'Madera'),
('ARCHICEN000000000004', 'Otros');


--CENTRO M�DICO D�NDE SE ATIENDE
GO
INSERT INTO centromedicos(id, descripcion) VALUES
('ARCHICEN000000000001','EsSalud'),
('ARCHICEN000000000002',  'Posta M�dica'),
('ARCHICEN000000000003', 'M�dico Particular');

--FRECUENCIA QUE VA AL M�DICO
GO
INSERT INTO frecuenciamedicos(id, descripcion) VALUES
('ARCHICEN000000000001','Una vez por semana'),
('ARCHICEN000000000002','Mensualmente'),
('ARCHICEN000000000003',  'Anualmente'),
('ARCHICEN000000000004', 'Cuando se enferma');

--FRECUENCIA QUE SE REALIZA EXAMENES
GO
INSERT INTO frecuenciaexamenes(id, descripcion) VALUES
('ARCHICEN000000000001','Mensualmente'),
('ARCHICEN000000000002',  'Anualmente'),
('ARCHICEN000000000003', 'Cuando se enferma');



