select * from tipocontratos

select * from TRABAJADORES

select * from tipodocumentos

select * from regimeninstituciones

select * from tipoinstituciones

select * from instituciones

select * from carreras

select * from provincias
